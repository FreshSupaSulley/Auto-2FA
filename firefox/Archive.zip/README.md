# Firefox
This is the code for the Firefox edition of Duochrome. There are slight differences in the code but the functionality always remains the same.
