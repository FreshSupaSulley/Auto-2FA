# Chrome / Edge
This is the code for the Chrome / Edge edition of DuOSU.
